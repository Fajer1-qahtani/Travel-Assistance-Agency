/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.travelassistance;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author hp
 */
public class TravelAssistance {

   

     static String main_menu = 
 "\n ** Welcome to the Travel assistance Agency **\n"+
 "are you new here or do you have an account? \n"+ 
 "1- I am new, sign up\n" + 
 "2- I have an account_login\n" + 
  "3- Exit \n"+          
   "Your Choice: " ;
    
   static String newUser_menu = "\n\t*** Welcome  ***\n"+
 "\t1- add your personal information \n" +
 "\t2- add your Escort information \n" +
  "\t3- Exit \n"+
 "\tYour Choice: " ;     
            
   static String login = "\n\t*** Welcome  ***\n";

 
              
// static String choice_menu = "\n\t*** Welcome to  ***\n"+
// "how can we help you ?"+   
// "\t1- Countries to visit \n" +
// "\t2- Hotel assistance \n" +
// "\t3- landmarks\n"+
// "\t4- Exit \n"+
// "\tYour Choice: " ;
 
//  static Scanner input =new Scanner(System.in);
    static UserInfo newUser;
    static UserInfo log_in;
    static EscortInfo newEscort;
    static String userName;
    static String national_ID;
    static String email;
    static String password;
    static String phoneNumber;
    static int numOfEscorts;
    static int age;
   
    
 
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in); 
        int choice;
 do{
 System.out.print(main_menu);
 choice = input.nextInt();

 switch(choice){
 case 1:
 newUser_menu();
break;
 case 2:
 login();
break;
 case 3:
   break;
 default:
System.out.print("Wrong Entry. Please enter a valid option.");
    
 }    
 
 
        ArrayList<Destination> countries = new ArrayList<Destination>();
        countries.add(new Destination ("USA" , "Seattle" , "Silver cloud Hotel", "Mukilteo", 150, 1000,1150) );
        countries.add(new Destination("UK","London", "New road hotel", "big ben", 300 , 2500 , 2800));
        countries.add(new Destination ("Japan" , "Tokyo","palace hotel Tokyo", "Sky Tree", 450, 1500, 1950));
        countries.add(new Destination("Korea", "Seoul" , "The Shilla Seoul", "Incheon Bridge",250 , 3000, 3250));
        countries.add(new Destination("France", "Paris"," the four season" , "Effil tower",100 , 500, 600 ));
        
         System.out.println("which country do you want to visit : ");
        for(int i = 0 ; i < countries.size() ; i++ ){
            System.out.println(countries.get(i).Country + "\n" 
            +"the most suitable city for you :" +countries.get(i).city + "\n"
            +"the best hotel for you is : " + countries.get(i).hotel+ "\n"
            +"intresting landmark : " +countries.get(i).landMarks + "\n" 
            +"the hotel price is : " +countries.get(i).price.getHotelPrice() + "\n"  
            +" the flight ticket price is : " +countries.get(i).price.getFlightTickets() + "\n" 
             +" the total price is : " +countries.get(i).price.calcPrice() + "\n");  
        }
    } while(choice != 3);
    }
    static void newUser_menu(){
    Scanner input = new Scanner (System.in);    
    int choice;
    do{
       System.out.println(newUser_menu);
       choice = input.nextInt();
       
       
    switch(choice){
        case 1:
        input.nextLine();
        
        System.out.print("\tPlease enter your username:");
        userName = input.nextLine();
        System.out.print("\tPlease enter your password :");
        password = input.nextLine();
        System.out.print("\tPlease enter your national ID :");
        national_ID = input.nextLine();
        System.out.print("\tPlease enter your email :");
        email = input.nextLine();
        System.out.print("\tPlease enter your phone number :");
        phoneNumber = input.nextLine();
        
        newUser = new UserInfo( userName,  national_ID,  email,  phoneNumber);
        System.out.println(newUser.toString());
        break;
        case 2:
         input.nextLine();
        
        System.out.print("\tPlease enter how many escorts will you add? :");
        numOfEscorts = input.nextInt();
        System.out.print("\tPlease enter your national ID :");
        national_ID = input.nextLine();
        System.out.print("\tPlease enter your email :");
        email = input.nextLine();
        System.out.print("\tPlease enter your phone number :");
        phoneNumber = input.nextLine();
        System.out.print("\tPlease enter your age :");
        age = input.nextInt();
         
        break;
        case 3:
            break;
      
        
        

  
    }      
} while(choice != 3);     
}
    
 static void login(){  
    Scanner input = new Scanner (System.in); 
     System.out.println("enter your username : " );
     userName = input.nextLine();   
     System.out.println("Enter your password :" );
     password = input.nextLine();   
      System.out.println(login);
 }
    

} 
  